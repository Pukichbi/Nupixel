package app.nupixel.project

import app.nupixel.core.Limits
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

const val CURRENT_FORMAT_VERSION = 1

class ProjectFormatException(message: String, cause: Throwable? = null) : Exception(message, cause)
class UnsupportedVersionException(val found: Int) : Exception("Unsupported formatVersion $found")

data class LayerEntry(
    val id: String,
    val name: String,
    val file: String,
    val visible: Boolean,
    val opacity: Float,
    val locked: Boolean,
    /** Этап 1: только "normal". Неизвестные значения читаются как normal. */
    val blendMode: String = "normal",
)

data class ProjectManifest(
    val formatVersion: Int = CURRENT_FORMAT_VERSION,
    val appVersion: String,
    val name: String,
    val width: Int,
    val height: Int,
    val dpi: Int,
    val colorProfile: String = "sRGB",
    /** Снизу вверх. */
    val layers: List<LayerEntry>,
)

object ManifestCodec {
    private val ID = Regex("[A-Za-z0-9_-]{1,64}")
    val LAYER_FILE = Regex("layers/[A-Za-z0-9_-]{1,64}\\.png")

    fun encode(m: ProjectManifest): String {
        validate(m)
        val layers = JSONArray()
        for (l in m.layers) {
            layers.put(
                JSONObject()
                    .put("id", l.id)
                    .put("name", l.name)
                    .put("file", l.file)
                    .put("visible", l.visible)
                    .put("opacity", l.opacity.toDouble())
                    .put("locked", l.locked)
                    .put("blendMode", l.blendMode),
            )
        }
        return JSONObject()
            .put("formatVersion", m.formatVersion)
            .put("appVersion", m.appVersion)
            .put("name", m.name)
            .put("width", m.width)
            .put("height", m.height)
            .put("dpi", m.dpi)
            .put("colorProfile", m.colorProfile)
            .put("layers", layers)
            .toString(2)
    }

    fun decode(text: String): ProjectManifest {
        val raw = try {
            JSONObject(text)
        } catch (e: JSONException) {
            throw ProjectFormatException("manifest is not valid JSON", e)
        }
        val json = Migrations.upgrade(raw)
        val manifest = try {
            parse(json)
        } catch (e: JSONException) {
            throw ProjectFormatException("manifest field error: ${e.message}", e)
        }
        validate(manifest)
        return manifest
    }

    private fun parse(j: JSONObject): ProjectManifest {
        val arr = j.getJSONArray("layers")
        val layers = (0 until arr.length()).map { i ->
            val l = arr.getJSONObject(i)
            LayerEntry(
                id = l.getString("id"),
                name = l.getString("name"),
                file = l.getString("file"),
                visible = l.getBoolean("visible"),
                opacity = l.getDouble("opacity").toFloat(),
                locked = l.optBoolean("locked", false),
                blendMode = l.optString("blendMode", "normal"),
            )
        }
        return ProjectManifest(
            formatVersion = j.getInt("formatVersion"),
            appVersion = j.optString("appVersion", ""),
            name = j.getString("name"),
            width = j.getInt("width"),
            height = j.getInt("height"),
            dpi = j.optInt("dpi", 72),
            colorProfile = j.optString("colorProfile", "sRGB"),
            layers = layers,
        )
    }

    fun validate(m: ProjectManifest) {
        fun fail(msg: String): Nothing = throw ProjectFormatException(msg)
        if (m.width !in Limits.MIN_SIDE..Limits.MAX_SIDE || m.height !in Limits.MIN_SIDE..Limits.MAX_SIDE) fail("canvas size out of range")
        if (m.dpi !in Limits.MIN_DPI..Limits.MAX_DPI) fail("dpi out of range")
        if (m.name.length > 256) fail("project name too long")
        if (m.layers.size > Limits.MAX_LAYERS) fail("too many layers")
        val seen = HashSet<String>()
        for (l in m.layers) {
            if (!ID.matches(l.id)) fail("bad layer id")
            if (!seen.add(l.id)) fail("duplicate layer id")
            if (!LAYER_FILE.matches(l.file)) fail("bad layer file name")
            if (l.name.length > 256) fail("layer name too long")
            if (l.opacity.isNaN() || l.opacity < 0f || l.opacity > 1f) fail("layer opacity out of range")
        }
    }
}

/** Миграции формата. Ключ N — шаг, переводящий версию N в N+1 (правит JSON на месте). */
object Migrations {
    private val steps: Map<Int, (JSONObject) -> Unit> = emptyMap()

    fun upgrade(json: JSONObject): JSONObject {
        var version = json.optInt("formatVersion", -1)
        if (version < 1) throw ProjectFormatException("missing or invalid formatVersion")
        if (version > CURRENT_FORMAT_VERSION) throw UnsupportedVersionException(version)
        while (version < CURRENT_FORMAT_VERSION) {
            val step = steps[version] ?: throw ProjectFormatException("no migration from version $version")
            step(json)
            version++
            json.put("formatVersion", version)
        }
        return json
    }
}
