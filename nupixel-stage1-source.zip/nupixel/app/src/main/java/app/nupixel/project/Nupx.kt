package app.nupixel.project

import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class ProjectData(val manifest: ProjectManifest, val layerPng: Map<String, ByteArray>)

/** Контейнер .nupx: ZIP с manifest.json и layers/<id>.png. См. docs/PROJECT_FORMAT.md. */
object Nupx {
    const val MANIFEST = "manifest.json"
    private const val MAX_ENTRIES = 600
    private const val MAX_MANIFEST_BYTES = 1 * 1024 * 1024
    private const val MAX_LAYER_BYTES = 128 * 1024 * 1024

    /** Слои запрашиваются по одному, чтобы не держать все PNG в памяти одновременно. */
    fun write(out: OutputStream, manifest: ProjectManifest, layerBytes: (LayerEntry) -> ByteArray) {
        val manifestText = ManifestCodec.encode(manifest)
        val zip = ZipOutputStream(BufferedOutputStream(out))
        zip.putNextEntry(ZipEntry(MANIFEST))
        zip.write(manifestText.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
        for (layer in manifest.layers) {
            zip.putNextEntry(ZipEntry(layer.file))
            zip.write(layerBytes(layer))
            zip.closeEntry()
        }
        zip.finish()
        zip.flush()
    }

    fun read(input: InputStream): ProjectData {
        val zip = ZipInputStream(input)
        var manifestText: String? = null
        val files = HashMap<String, ByteArray>()
        var count = 0
        while (true) {
            val entry = zip.nextEntry ?: break
            if (++count > MAX_ENTRIES) throw ProjectFormatException("too many entries")
            if (entry.isDirectory) continue
            val name = entry.name
            val limit = when {
                name == MANIFEST -> MAX_MANIFEST_BYTES
                ManifestCodec.LAYER_FILE.matches(name) -> MAX_LAYER_BYTES
                else -> continue // неизвестные записи игнорируются (прямая совместимость)
            }
            val bytes = readLimited(zip, limit)
            if (name == MANIFEST) manifestText = String(bytes, Charsets.UTF_8) else files[name] = bytes
        }
        val text = manifestText ?: throw ProjectFormatException("manifest.json missing")
        val manifest = ManifestCodec.decode(text)
        for (layer in manifest.layers) {
            if (!files.containsKey(layer.file)) throw ProjectFormatException("missing ${layer.file}")
        }
        return ProjectData(manifest, files)
    }

    private fun readLimited(stream: InputStream, limit: Int): ByteArray {
        val bos = ByteArrayOutputStream()
        val buf = ByteArray(64 * 1024)
        var total = 0L
        while (true) {
            val n = stream.read(buf)
            if (n < 0) break
            total += n
            if (total > limit) throw ProjectFormatException("entry too large")
            bos.write(buf, 0, n)
        }
        return bos.toByteArray()
    }
}

object SafeFile {
    /** Запись во временный файл, fsync и атомарное переименование: старый файл не теряется при сбое. */
    fun writeAtomically(target: File, block: (OutputStream) -> Unit) {
        val dir = target.absoluteFile.parentFile ?: throw java.io.IOException("no parent dir")
        dir.mkdirs()
        val tmp = File(dir, target.name + ".tmp")
        try {
            FileOutputStream(tmp).use { fos ->
                val out = BufferedOutputStream(fos)
                block(out)
                out.flush()
                fos.fd.sync()
            }
            Files.move(
                tmp.toPath(), target.toPath(),
                StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING,
            )
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }
}
