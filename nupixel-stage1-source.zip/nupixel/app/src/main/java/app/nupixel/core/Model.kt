package app.nupixel.core

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import kotlin.math.roundToInt

const val APP_VERSION = "0.1.0"

/** Ограничения этапа 1. Тайловый рендеринг в следующих этапах снимет часть из них. */
object Limits {
    const val MIN_SIDE = 1
    /** 4096×4096×4 = 64 МБ — ниже лимита аппаратной отрисовки Android (100 МБ на битмап). */
    const val MAX_SIDE = 4096
    const val MAX_IMPORT_PIXELS = 16_000_000L
    const val MAX_LAYERS = 64
    const val MIN_DPI = 1
    const val MAX_DPI = 2400
}

class InsufficientMemoryException : Exception("Not enough memory for this operation")
class InvalidImageException : Exception("Unsupported or damaged image")

object MemoryGuard {
    fun bytesFor(width: Int, height: Int): Long = width.toLong() * height * 4

    /** Бюджет пикселей слоёв — 60% кучи приложения. */
    fun require(extraBytes: Long, currentBytes: Long) {
        val budget = Runtime.getRuntime().maxMemory() * 6 / 10
        if (currentBytes + extraBytes > budget) throw InsufficientMemoryException()
    }
}

data class LayerState(
    val id: String,
    val name: String,
    val bitmap: Bitmap,
    val visible: Boolean = true,
    val opacity: Float = 1f,
    val locked: Boolean = false,
)

data class DocState(
    val name: String,
    val width: Int,
    val height: Int,
    val dpi: Int = 72,
    /** Порядок снизу вверх: индекс 0 — нижний слой. */
    val layers: List<LayerState>,
    /** Увеличивается при каждом изменении; нужен для перерисовки. */
    val revision: Long = 0,
) {
    val pixelBytes: Long get() = layers.sumOf { it.bitmap.allocationByteCount.toLong() }
}

object Compositor {
    /** Склейка видимых слоёв (режим наложения — только Normal на этапе 1). */
    fun flatten(doc: DocState, backgroundColor: Int? = null): Bitmap {
        val out = Bitmap.createBitmap(doc.width, doc.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        if (backgroundColor != null) canvas.drawColor(backgroundColor)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        for (layer in doc.layers) {
            if (!layer.visible) continue
            paint.alpha = (layer.opacity.coerceIn(0f, 1f) * 255f).roundToInt()
            canvas.drawBitmap(layer.bitmap, 0f, 0f, paint)
        }
        return out
    }
}
