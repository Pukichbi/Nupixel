package app.nupixel.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import androidx.annotation.StringRes
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.nupixel.R
import app.nupixel.core.DocState
import app.nupixel.core.InsufficientMemoryException
import app.nupixel.core.InvalidImageException
import app.nupixel.core.LayerState
import app.nupixel.core.Limits
import app.nupixel.core.LocaleHelper
import app.nupixel.core.MemoryGuard
import app.nupixel.core.Prefs
import app.nupixel.io.ExportFormat
import app.nupixel.io.Exporter
import app.nupixel.io.ImageImport
import app.nupixel.project.Nupx
import app.nupixel.project.ProjectCodec
import app.nupixel.project.ProjectFormatException
import app.nupixel.project.SafeFile
import app.nupixel.project.UnsupportedVersionException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID

data class UiMessage(@StringRes val resId: Int, val args: List<Any> = emptyList())

class EditorViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    private val autosaveDir = File(app.filesDir, "autosave")
    private val autosaveFile = File(autosaveDir, "current.nupx")
    private val autosaveMutex = Mutex()
    private var autosaveJob: Job? = null

    var doc by mutableStateOf<DocState?>(null)
        private set
    var dirty by mutableStateOf(false)
        private set
    /** Строковый ресурс подписи текущей фоновой операции или null. */
    var busy by mutableStateOf<Int?>(null)
        private set
    var themeMode by mutableStateOf(prefs.theme)
        private set
    /** Увеличивается, когда вид нужно вписать в экран (новый документ, кнопка «Вписать»). */
    var fitRequest by mutableIntStateOf(0)
        private set

    private val messageChannel = Channel<UiMessage>(Channel.BUFFERED)
    val messages = messageChannel.receiveAsFlow()

    init {
        recoverAutosave()
    }

    // ---------- Настройки ----------

    fun setTheme(mode: String) {
        prefs.theme = mode
        themeMode = mode
    }

    /** После вызова Activity должна пересоздаться (recreate). */
    fun setLanguage(lang: String) {
        prefs.language = lang
    }

    val language: String get() = prefs.language

    fun requestFit() {
        fitRequest++
    }

    // ---------- Документ ----------

    fun newCanvas(width: Int, height: Int) {
        if (busy != null) return
        if (width !in Limits.MIN_SIDE..Limits.MAX_SIDE || height !in Limits.MIN_SIDE..Limits.MAX_SIDE) return
        task(R.string.working, work = {
            MemoryGuard.require(MemoryGuard.bytesFor(width, height), 0)
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            DocState(
                name = str(R.string.untitled), width = width, height = height,
                layers = listOf(LayerState(newId(), str(R.string.background_layer), bmp)),
            )
        }) { replaceDocument(it, dirtyAfter = false) }
    }

    private class ImportResult(val doc: DocState, val addedAsLayer: Boolean, val downsampled: Boolean, val width: Int, val height: Int)

    /** asLayer=false — открыть как новый документ; true — добавить слоем в текущий. */
    fun importImage(uri: Uri, asLayer: Boolean) {
        if (busy != null) return
        val current = doc
        task(R.string.working, work = {
            val resolver = getApplication<Application>().contentResolver
            val img = ImageImport.decode(resolver, uri, str(R.string.image_layer_fallback))
            val w = img.bitmap.width
            val h = img.bitmap.height
            if (asLayer && current != null) {
                if (current.layers.size >= Limits.MAX_LAYERS) throw LayerLimitException()
                MemoryGuard.require(MemoryGuard.bytesFor(current.width, current.height), current.pixelBytes)
                val layerBmp = ImageImport.fitIntoCanvas(img.bitmap, current.width, current.height)
                img.bitmap.recycle()
                val layer = LayerState(newId(), img.displayName, layerBmp)
                ImportResult(current.copy(layers = current.layers + layer, revision = current.revision + 1), true, img.downsampled, w, h)
            } else {
                val d = DocState(
                    name = img.displayName, width = w, height = h,
                    layers = listOf(LayerState(newId(), img.displayName, img.bitmap)),
                )
                ImportResult(d, false, img.downsampled, w, h)
            }
        }) { r ->
            if (r.addedAsLayer) {
                doc = r.doc
                markDirty()
            } else {
                replaceDocument(r.doc, dirtyAfter = true)
                scheduleAutosave()
            }
            if (r.downsampled) post(R.string.msg_imported_downsized, r.width, r.height)
        }
    }

    fun openProject(uri: Uri) {
        if (busy != null) return
        task(R.string.working, work = {
            val input = getApplication<Application>().contentResolver.openInputStream(uri)
                ?: throw IOException("cannot open $uri")
            input.use { ProjectCodec.read(it) }
        }) { replaceDocument(it, dirtyAfter = false) }
    }

    fun saveProject(uri: Uri) {
        val snapshot = doc ?: return
        if (busy != null) return
        task(R.string.saving, work = {
            val temp = File(getApplication<Application>().cacheDir, "save-${System.nanoTime()}.nupx")
            try {
                SafeFile.writeAtomically(temp) { ProjectCodec.write(it, snapshot) }
                // Проверяем, что получившийся файл читается, прежде чем трогать целевой.
                FileInputStream(temp).use { Nupx.read(it) }
                copyToUri(temp, uri)
            } finally {
                temp.delete()
            }
        }) {
            dirty = false
            autosaveJob?.cancel()
            deleteAutosave()
            post(R.string.msg_saved)
        }
    }

    fun export(uri: Uri, format: ExportFormat, quality: Int) {
        val snapshot = doc ?: return
        if (busy != null) return
        task(R.string.exporting, work = {
            val temp = File(getApplication<Application>().cacheDir, "export-${System.nanoTime()}.${format.ext}")
            try {
                FileOutputStream(temp).use { Exporter.encode(snapshot, format, quality, it) }
                copyToUri(temp, uri)
            } finally {
                temp.delete()
            }
        }) { post(R.string.msg_exported) }
    }

    // ---------- Слои ----------

    fun toggleVisible(id: String) = updateLayer(id) { it.copy(visible = !it.visible) }

    fun setOpacity(id: String, value: Float) = updateLayer(id) { it.copy(opacity = value.coerceIn(0f, 1f)) }

    fun deleteLayer(id: String) {
        val d = doc ?: return
        if (d.layers.size <= 1) return
        doc = d.copy(layers = d.layers.filter { it.id != id }, revision = d.revision + 1)
        markDirty()
    }

    private fun updateLayer(id: String, change: (LayerState) -> LayerState) {
        val d = doc ?: return
        doc = d.copy(layers = d.layers.map { if (it.id == id) change(it) else it }, revision = d.revision + 1)
        markDirty()
    }

    // ---------- Автосохранение и восстановление ----------

    private fun markDirty() {
        dirty = true
        scheduleAutosave()
    }

    private fun scheduleAutosave() {
        autosaveJob?.cancel()
        autosaveJob = viewModelScope.launch {
            delay(3000)
            val snapshot = doc ?: return@launch
            try {
                autosaveMutex.withLock {
                    withContext(Dispatchers.IO) {
                        SafeFile.writeAtomically(autosaveFile) { ProjectCodec.write(it, snapshot) }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                // Сбой автосохранения не должен ронять приложение; пользователь по-прежнему может сохранить вручную.
            }
        }
    }

    private fun deleteAutosave() {
        viewModelScope.launch(Dispatchers.IO) {
            autosaveMutex.withLock {
                autosaveFile.delete()
            }
        }
    }

    private fun recoverAutosave() {
        if (!autosaveFile.exists()) return
        task(R.string.working, work = {
            try {
                FileInputStream(autosaveFile).use { ProjectCodec.read(it) }
            } catch (t: Throwable) {
                // Повреждённый файл переименовываем, чтобы не пытаться читать его при каждом запуске.
                autosaveFile.renameTo(File(autosaveDir, "current.nupx.bad"))
                throw t
            }
        }) {
            replaceDocument(it, dirtyAfter = true)
            post(R.string.msg_recovered)
        }
    }

    // ---------- Вспомогательное ----------

    private fun replaceDocument(newDoc: DocState, dirtyAfter: Boolean) {
        doc = newDoc
        dirty = dirtyAfter
        fitRequest++
        if (!dirtyAfter) {
            autosaveJob?.cancel()
            deleteAutosave()
        }
    }

    private fun <T> task(@StringRes label: Int, work: () -> T, onDone: (T) -> Unit) {
        viewModelScope.launch {
            busy = label
            try {
                val result = withContext(Dispatchers.IO) { work() }
                onDone(result)
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                post(errorFor(t))
            } finally {
                busy = null
            }
        }
    }

    private class LayerLimitException : Exception()

    private fun errorFor(t: Throwable): Int = when (t) {
        is InvalidImageException -> R.string.err_invalid_image
        is UnsupportedVersionException -> R.string.err_unsupported_version
        is ProjectFormatException -> R.string.err_invalid_project
        is InsufficientMemoryException, is OutOfMemoryError -> R.string.err_out_of_memory
        is LayerLimitException -> R.string.err_layer_limit
        is IOException -> R.string.err_io
        else -> R.string.err_unknown
    }

    private fun copyToUri(source: File, uri: Uri) {
        val out = getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
            ?: throw IOException("cannot open $uri")
        out.use { o -> FileInputStream(source).use { it.copyTo(o) } }
    }

    private fun post(@StringRes id: Int, vararg args: Any) {
        messageChannel.trySend(UiMessage(id, args.toList()))
    }

    private fun str(@StringRes id: Int): String =
        LocaleHelper.wrap(getApplication<Application>(), prefs.language).getString(id)

    private fun newId(): String = UUID.randomUUID().toString().replace("-", "").take(16)
}
