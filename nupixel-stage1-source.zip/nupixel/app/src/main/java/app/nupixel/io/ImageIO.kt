package app.nupixel.io

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.exifinterface.media.ExifInterface
import app.nupixel.core.Compositor
import app.nupixel.core.DocState
import app.nupixel.core.InvalidImageException
import app.nupixel.core.Limits
import java.io.IOException
import java.io.OutputStream
import kotlin.math.max
import kotlin.math.min

class ImportedImage(val bitmap: Bitmap, val downsampled: Boolean, val displayName: String)

object ImageImport {
    /** Проверяет файл, ограничивает размер по памяти (inSampleSize) и применяет EXIF-ориентацию. */
    fun decode(resolver: ContentResolver, uri: Uri, fallbackName: String): ImportedImage {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val s1 = resolver.openInputStream(uri) ?: throw IOException("cannot open $uri")
        s1.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw InvalidImageException()

        var sample = 1
        while (
            (bounds.outWidth.toLong() / sample) * (bounds.outHeight.toLong() / sample) > Limits.MAX_IMPORT_PIXELS ||
            max(bounds.outWidth, bounds.outHeight) / sample > Limits.MAX_SIDE
        ) sample *= 2

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inMutable = true
        }
        val s2 = resolver.openInputStream(uri) ?: throw IOException("cannot open $uri")
        val raw = s2.use { BitmapFactory.decodeStream(it, null, opts) } ?: throw InvalidImageException()

        val orientation = try {
            resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: IOException) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val oriented = ensureMutable(applyOrientation(raw, orientation))
        return ImportedImage(oriented, sample > 1, displayName(resolver, uri) ?: fallbackName)
    }

    /** Холст размера canvasW×canvasH с изображением по центру; уменьшается по размеру, но не увеличивается. */
    fun fitIntoCanvas(src: Bitmap, canvasW: Int, canvasH: Int): Bitmap {
        val out = Bitmap.createBitmap(canvasW, canvasH, Bitmap.Config.ARGB_8888)
        val scale = min(1f, min(canvasW / src.width.toFloat(), canvasH / src.height.toFloat()))
        val w = src.width * scale
        val h = src.height * scale
        val m = Matrix().apply {
            postScale(scale, scale)
            postTranslate((canvasW - w) / 2f, (canvasH - h) / 2f)
        }
        Canvas(out).drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    private fun ensureMutable(b: Bitmap): Bitmap =
        if (b.isMutable && b.config == Bitmap.Config.ARGB_8888) b else b.copy(Bitmap.Config.ARGB_8888, true)

    private fun applyOrientation(src: Bitmap, orientation: Int): Bitmap {
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.setScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.setRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> { m.setRotate(180f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.setRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_90 -> m.setRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.setRotate(-90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_270 -> m.setRotate(-90f)
            else -> return src
        }
        val rotated = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
        if (rotated !== src) src.recycle()
        return rotated
    }

    private fun displayName(resolver: ContentResolver, uri: Uri): String? = try {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.substringBeforeLast('.')?.take(120) else null
        }
    } catch (e: Exception) {
        null
    }
}

enum class ExportFormat(val mime: String, val ext: String, val hasQuality: Boolean, val hasAlpha: Boolean) {
    PNG("image/png", "png", false, true),
    JPEG("image/jpeg", "jpg", true, false),
    WEBP("image/webp", "webp", true, true),
}

object Exporter {
    /** Склеивает видимые слои и кодирует. JPEG не поддерживает прозрачность — подкладывается белый фон. */
    fun encode(doc: DocState, format: ExportFormat, quality: Int, out: OutputStream) {
        val flat = Compositor.flatten(doc, if (format.hasAlpha) null else Color.WHITE)
        try {
            val q = quality.coerceIn(1, 100)
            if (!flat.compress(compressFormat(format, q), q, out)) throw IOException("encode failed")
        } finally {
            flat.recycle()
        }
    }

    @Suppress("DEPRECATION")
    private fun compressFormat(format: ExportFormat, quality: Int): Bitmap.CompressFormat = when (format) {
        ExportFormat.PNG -> Bitmap.CompressFormat.PNG
        ExportFormat.JPEG -> Bitmap.CompressFormat.JPEG
        ExportFormat.WEBP ->
            if (Build.VERSION.SDK_INT >= 30) {
                if (quality >= 100) Bitmap.CompressFormat.WEBP_LOSSLESS else Bitmap.CompressFormat.WEBP_LOSSY
            } else {
                Bitmap.CompressFormat.WEBP
            }
    }
}
