package app.nupixel.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import app.nupixel.R
import app.nupixel.core.DocState
import app.nupixel.core.Limits
import app.nupixel.io.ExportFormat
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: EditorViewModel) {
    val context = LocalContext.current
    val activity = context as? Activity
    val snackbar = remember { SnackbarHostState() }
    val doc = vm.doc

    var menuOpen by remember { mutableStateOf(false) }
    var showNew by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    var showLayers by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var uiHidden by rememberSaveable { mutableStateOf(false) }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    var exportQuality by remember { mutableIntStateOf(90) }

    // Действие, которое может отбросить несохранённые изменения, сначала спрашивает подтверждение.
    fun guarded(action: () -> Unit) {
        if (vm.dirty) pending = action else action()
    }

    val openImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.importImage(it, asLayer = false) }
    }
    val addImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.importImage(it, asLayer = true) }
    }
    val openProject = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.openProject(it) }
    }
    val saveProject = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream"),
    ) { uri -> uri?.let { vm.saveProject(it) } }
    val exportPng = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        uri?.let { vm.export(it, ExportFormat.PNG, exportQuality) }
    }
    val exportJpeg = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/jpeg")) { uri ->
        uri?.let { vm.export(it, ExportFormat.JPEG, exportQuality) }
    }
    val exportWebp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/webp")) { uri ->
        uri?.let { vm.export(it, ExportFormat.WEBP, exportQuality) }
    }

    val imageTypes = arrayOf("image/*")

    fun startOpenImage() = guarded { openImage.launch(imageTypes) }
    fun startOpenProject() = guarded { openProject.launch(arrayOf("*/*")) }

    LaunchedEffect(Unit) {
        vm.messages.collect { m ->
            snackbar.showSnackbar(context.getString(m.resId, *m.args.toTypedArray()))
        }
    }

    BackHandler(enabled = vm.dirty) { pending = { activity?.finish() } }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbar) },
            topBar = {
                if (!uiHidden) {
                    TopAppBar(
                        title = { Text(doc?.name ?: stringResource(R.string.app_name)) },
                        actions = {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = stringResource(R.string.menu))
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.new_canvas)) },
                                    onClick = { menuOpen = false; guarded { showNew = true } },
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.open_image)) },
                                    onClick = { menuOpen = false; startOpenImage() },
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.add_image_layer)) },
                                    enabled = doc != null,
                                    onClick = { menuOpen = false; addImage.launch(imageTypes) },
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.open_project)) },
                                    onClick = { menuOpen = false; startOpenProject() },
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.save_project)) },
                                    enabled = doc != null,
                                    onClick = { menuOpen = false; saveProject.launch(fileName(doc, "nupx")) },
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.export_image)) },
                                    enabled = doc != null,
                                    onClick = { menuOpen = false; showExport = true },
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.settings)) },
                                    onClick = { menuOpen = false; showSettings = true },
                                )
                            }
                        },
                    )
                }
            },
            bottomBar = {
                if (!uiHidden && doc != null) {
                    BottomAppBar {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            TextButton(onClick = { showLayers = true }) { Text(stringResource(R.string.layers)) }
                            TextButton(onClick = { vm.requestFit() }) { Text(stringResource(R.string.fit_view)) }
                            TextButton(onClick = { uiHidden = true }) { Text(stringResource(R.string.hide_panels)) }
                        }
                    }
                }
            },
        ) { padding ->
            Box(
                Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background),
            ) {
                if (doc != null) {
                    CanvasView(doc = doc, fitRequest = vm.fitRequest)
                } else {
                    EmptyState(
                        onNew = { showNew = true },
                        onOpenImage = { startOpenImage() },
                        onOpenProject = { startOpenProject() },
                    )
                }
                if (uiHidden) {
                    FilledTonalIconButton(
                        onClick = { uiHidden = false },
                        modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp),
                    ) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.show_panels))
                    }
                }
            }
        }

        vm.busy?.let { label ->
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0x99000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Text(stringResource(label), color = Color.White, modifier = Modifier.padding(top = 12.dp))
                }
            }
        }
    }

    if (showNew) {
        NewCanvasDialog(
            onDismiss = { showNew = false },
            onCreate = { w, h -> showNew = false; vm.newCanvas(w, h) },
        )
    }
    if (showExport && doc != null) {
        ExportDialog(
            onDismiss = { showExport = false },
            onExport = { format, quality ->
                showExport = false
                exportQuality = quality
                val name = fileName(doc, format.ext)
                when (format) {
                    ExportFormat.PNG -> exportPng.launch(name)
                    ExportFormat.JPEG -> exportJpeg.launch(name)
                    ExportFormat.WEBP -> exportWebp.launch(name)
                }
            },
        )
    }
    if (showSettings) {
        SettingsDialog(
            language = vm.language,
            theme = vm.themeMode,
            onLanguage = { vm.setLanguage(it); activity?.recreate() },
            onTheme = { vm.setTheme(it) },
            onDismiss = { showSettings = false },
        )
    }
    if (showLayers && doc != null) {
        ModalBottomSheet(onDismissRequest = { showLayers = false }) {
            LayersPanel(doc, vm)
        }
    }
    pending?.let { action ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text(stringResource(R.string.unsaved_title)) },
            text = { Text(stringResource(R.string.unsaved_message)) },
            confirmButton = {
                TextButton(onClick = { pending = null; action() }) { Text(stringResource(R.string.discard)) }
            },
            dismissButton = {
                TextButton(onClick = { pending = null }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}

private fun fileName(doc: DocState?, ext: String): String {
    val base = (doc?.name ?: "nupixel").replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "nupixel" }
    return "$base.$ext"
}

@Composable
private fun EmptyState(onNew: () -> Unit, onOpenImage: () -> Unit, onOpenProject: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(stringResource(R.string.empty_title), style = MaterialTheme.typography.headlineSmall)
        Text(
            stringResource(R.string.empty_hint),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 12.dp),
        )
        Button(onClick = onNew, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.new_canvas)) }
        OutlinedButton(onClick = onOpenImage, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            Text(stringResource(R.string.open_image))
        }
        OutlinedButton(onClick = onOpenProject, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            Text(stringResource(R.string.open_project))
        }
    }
}

@Composable
private fun NewCanvasDialog(onDismiss: () -> Unit, onCreate: (Int, Int) -> Unit) {
    var w by remember { mutableStateOf("1080") }
    var h by remember { mutableStateOf("1080") }
    val wi = w.toIntOrNull()
    val hi = h.toIntOrNull()
    val range = Limits.MIN_SIDE..Limits.MAX_SIDE
    val valid = wi != null && hi != null && wi in range && hi in range
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.new_canvas)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1080 to 1080, 1920 to 1080, 2048 to 2048).forEach { (pw, ph) ->
                        TextButton(onClick = { w = pw.toString(); h = ph.toString() }) { Text("$pw×$ph") }
                    }
                }
                OutlinedTextField(
                    value = w, onValueChange = { w = it.filter(Char::isDigit).take(5) },
                    label = { Text(stringResource(R.string.width)) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                OutlinedTextField(
                    value = h, onValueChange = { h = it.filter(Char::isDigit).take(5) },
                    label = { Text(stringResource(R.string.height)) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    isError = !valid,
                    supportingText = { Text(stringResource(R.string.size_hint, Limits.MAX_SIDE)) },
                )
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = { onCreate(wi!!, hi!!) }) { Text(stringResource(R.string.create)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun ExportDialog(onDismiss: () -> Unit, onExport: (ExportFormat, Int) -> Unit) {
    var format by remember { mutableStateOf(ExportFormat.PNG) }
    var quality by remember { mutableIntStateOf(90) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.export_image)) },
        text = {
            Column {
                Text(stringResource(R.string.format), style = MaterialTheme.typography.labelLarge)
                ExportFormat.entries.forEach { f ->
                    Row(
                        Modifier.fillMaxWidth().clickable { format = f },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = format == f, onClick = { format = f })
                        Text(f.name)
                    }
                }
                if (format.hasQuality) {
                    Text(stringResource(R.string.quality, quality), modifier = Modifier.padding(top = 8.dp))
                    Slider(value = quality.toFloat(), onValueChange = { quality = it.roundToInt() }, valueRange = 1f..100f)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onExport(format, quality) }) { Text(stringResource(R.string.export_action)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun SettingsDialog(
    language: String,
    theme: String,
    onLanguage: (String) -> Unit,
    onTheme: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.settings)) },
        text = {
            Column {
                Text(stringResource(R.string.language), style = MaterialTheme.typography.labelLarge)
                OptionRow(stringResource(R.string.lang_system), language == "system") { onLanguage("system") }
                OptionRow(stringResource(R.string.lang_ru), language == "ru") { onLanguage("ru") }
                OptionRow(stringResource(R.string.lang_en), language == "en") { onLanguage("en") }
                Text(
                    stringResource(R.string.theme),
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(top = 12.dp),
                )
                OptionRow(stringResource(R.string.theme_dark), theme == "dark") { onTheme("dark") }
                OptionRow(stringResource(R.string.theme_light), theme == "light") { onTheme("light") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.ok)) } },
    )
}

@Composable
private fun OptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label)
    }
}

@Composable
private fun LayersPanel(doc: DocState, vm: EditorViewModel) {
    LazyColumn(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
        // Верхний слой — первым в списке.
        items(doc.layers.reversed(), key = { it.id }) { layer ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = layer.visible, onCheckedChange = { vm.toggleVisible(layer.id) })
                Column(Modifier.weight(1f)) {
                    Text(layer.name, maxLines = 1)
                    Text(
                        stringResource(R.string.opacity, (layer.opacity * 100).roundToInt()),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Slider(value = layer.opacity, onValueChange = { vm.setOpacity(layer.id, it) })
                }
                IconButton(onClick = { vm.deleteLayer(layer.id) }, enabled = doc.layers.size > 1) {
                    Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.delete_layer))
                }
            }
        }
    }
}
