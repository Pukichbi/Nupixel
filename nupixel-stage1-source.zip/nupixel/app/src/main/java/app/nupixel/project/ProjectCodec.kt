package app.nupixel.project

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import app.nupixel.core.APP_VERSION
import app.nupixel.core.DocState
import app.nupixel.core.LayerState
import app.nupixel.core.MemoryGuard
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/** Мост между документом в памяти и контейнером .nupx. */
object ProjectCodec {
    private fun layerFile(id: String) = "layers/$id.png"

    fun write(out: OutputStream, doc: DocState) {
        val entries = doc.layers.map {
            LayerEntry(it.id, it.name, layerFile(it.id), it.visible, it.opacity, it.locked)
        }
        val manifest = ProjectManifest(
            appVersion = APP_VERSION, name = doc.name,
            width = doc.width, height = doc.height, dpi = doc.dpi, layers = entries,
        )
        val byId = doc.layers.associateBy { layerFile(it.id) }
        Nupx.write(out, manifest) { entry -> toPng(byId.getValue(entry.file).bitmap) }
    }

    fun read(input: InputStream): DocState {
        val data = Nupx.read(input)
        val m = data.manifest
        MemoryGuard.require(MemoryGuard.bytesFor(m.width, m.height) * m.layers.size, 0)
        val layers = m.layers.map { e ->
            LayerState(
                id = e.id, name = e.name,
                bitmap = fromPng(data.layerPng.getValue(e.file), m.width, m.height),
                visible = e.visible, opacity = e.opacity, locked = e.locked,
            )
        }
        return DocState(m.name, m.width, m.height, m.dpi, layers)
    }

    fun toPng(bitmap: Bitmap): ByteArray {
        val bos = ByteArrayOutputStream()
        if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, bos)) throw IOException("PNG encode failed")
        return bos.toByteArray()
    }

    fun fromPng(bytes: ByteArray, width: Int, height: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth != width || bounds.outHeight != height) {
            throw ProjectFormatException("layer size does not match canvas")
        }
        val opts = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inMutable = true
        }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
            ?: throw ProjectFormatException("layer PNG cannot be decoded")
    }
}
