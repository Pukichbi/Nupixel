package app.nupixel.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Dark = darkColorScheme(
    primary = Color(0xFF5ED6C0),
    onPrimary = Color(0xFF00382F),
    secondary = Color(0xFF9D8CFF),
    background = Color(0xFF0F1115),
    onBackground = Color(0xFFE3E6EB),
    surface = Color(0xFF161920),
    onSurface = Color(0xFFE3E6EB),
    surfaceVariant = Color(0xFF232733),
    onSurfaceVariant = Color(0xFFB8BECC),
    error = Color(0xFFFF8A80),
)

private val Light = lightColorScheme(
    primary = Color(0xFF00796B),
    onPrimary = Color.White,
    secondary = Color(0xFF5B4BD6),
    background = Color(0xFFF6F7FA),
    onBackground = Color(0xFF15181E),
    surface = Color.White,
    onSurface = Color(0xFF15181E),
    surfaceVariant = Color(0xFFE6E9F0),
    onSurfaceVariant = Color(0xFF444B5A),
)

@Composable
fun NupixelTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
