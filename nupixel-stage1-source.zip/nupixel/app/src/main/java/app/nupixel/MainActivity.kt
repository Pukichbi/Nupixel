package app.nupixel

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import app.nupixel.core.LocaleHelper
import app.nupixel.core.Prefs
import app.nupixel.ui.EditorScreen
import app.nupixel.ui.EditorViewModel
import app.nupixel.ui.NupixelTheme

class MainActivity : ComponentActivity() {
    private val vm: EditorViewModel by viewModels()

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase, Prefs(newBase).language))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NupixelTheme(dark = vm.themeMode == "dark") {
                EditorScreen(vm)
            }
        }
    }
}
