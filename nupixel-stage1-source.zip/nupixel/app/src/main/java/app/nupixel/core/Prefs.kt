package app.nupixel.core

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** Настройки интерфейса. Читаются синхронно, поэтому подходят для attachBaseContext. */
class Prefs(context: Context) {
    // Не используем applicationContext: в attachBaseContext он ещё null.
    private val sp = context.getSharedPreferences("nupixel_prefs", Context.MODE_PRIVATE)

    /** "system" | "ru" | "en" */
    var language: String
        get() = sp.getString("language", "system") ?: "system"
        set(value) = sp.edit().putString("language", value).apply()

    /** "dark" (по умолчанию) | "light" */
    var theme: String
        get() = sp.getString("theme", "dark") ?: "dark"
        set(value) = sp.edit().putString("theme", value).apply()
}

object LocaleHelper {
    fun wrap(base: Context, language: String): Context {
        if (language == "system") return base
        val locale = Locale(language)
        Locale.setDefault(locale)
        val config = Configuration(base.resources.configuration)
        config.setLocale(locale)
        return base.createConfigurationContext(config)
    }
}
