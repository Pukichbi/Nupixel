package app.nupixel.ui

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import app.nupixel.core.DocState
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt

private const val MIN_SCALE = 0.02f
private const val MAX_SCALE = 64f

/**
 * Холст: показывает видимые слои с учётом непрозрачности.
 * Жесты: перемещение, масштаб и поворот двумя пальцами; двойное касание — вписать в экран.
 */
@Composable
fun CanvasView(doc: DocState, fitRequest: Int, modifier: Modifier = Modifier) {
    var size by remember { mutableStateOf(IntSize.Zero) }
    val matrix = remember { Matrix() } // изображение -> экран
    var tick by remember { mutableIntStateOf(0) }
    val currentDoc by rememberUpdatedState(doc)

    val checker = remember { checkerPaint() }
    val layerPaint = remember { Paint() }
    val clipPath = remember { Path() }
    val values = remember { FloatArray(9) }

    fun fit() {
        val d = currentDoc
        if (size.width == 0 || size.height == 0) return
        val s = min(size.width / d.width.toFloat(), size.height / d.height.toFloat()) * 0.95f
        matrix.reset()
        matrix.postScale(s, s)
        matrix.postTranslate((size.width - d.width * s) / 2f, (size.height - d.height * s) / 2f)
        tick++
    }

    LaunchedEffect(fitRequest, size != IntSize.Zero) { fit() }

    Canvas(
        modifier
            .fillMaxSize()
            .clipToBounds()
            .onSizeChanged { size = it }
            .pointerInput(Unit) {
                detectTransformGestures { centroid, pan, zoom, rotation ->
                    matrix.getValues(values)
                    val scale = hypot(values[Matrix.MSCALE_X], values[Matrix.MSKEW_X])
                    val z = if (scale * zoom in MIN_SCALE..MAX_SCALE) zoom else 1f
                    matrix.postScale(z, z, centroid.x, centroid.y)
                    matrix.postRotate(rotation, centroid.x, centroid.y)
                    matrix.postTranslate(pan.x, pan.y)
                    tick++
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = { fit() })
            },
    ) {
        tick // чтение состояния подписывает отрисовку на изменения жестов
        drawIntoCanvas { c ->
            val nc = c.nativeCanvas
            val d = currentDoc

            // Шахматный фон под прозрачностью — в экранных координатах, обрезан по границам холста.
            val rect = RectF(0f, 0f, d.width.toFloat(), d.height.toFloat())
            clipPath.reset()
            clipPath.addRect(rect, Path.Direction.CW)
            clipPath.transform(matrix)
            nc.save()
            nc.clipPath(clipPath)
            nc.drawRect(0f, 0f, this.size.width, this.size.height, checker)
            nc.restore()

            matrix.getValues(values)
            val scale = hypot(values[Matrix.MSCALE_X], values[Matrix.MSKEW_X])
            layerPaint.isFilterBitmap = scale < 4f // при сильном увеличении показываем чёткие пиксели

            nc.save()
            nc.concat(matrix)
            for (layer in d.layers) {
                if (!layer.visible) continue
                layerPaint.alpha = (layer.opacity.coerceIn(0f, 1f) * 255f).roundToInt()
                nc.drawBitmap(layer.bitmap, 0f, 0f, layerPaint)
            }
            nc.restore()
        }
    }
}

private fun checkerPaint(): Paint {
    val tile = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
    val light = 0xFFCFCFCF.toInt()
    val dark = 0xFFA8A8A8.toInt()
    for (y in 0 until 16) for (x in 0 until 16) {
        tile.setPixel(x, y, if ((x / 8 + y / 8) % 2 == 0) light else dark)
    }
    return Paint().apply { shader = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT) }
}
