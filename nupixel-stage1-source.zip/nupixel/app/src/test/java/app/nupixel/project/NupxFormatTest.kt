package app.nupixel.project

import org.json.JSONObject
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class NupxFormatTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private fun sample() = ProjectManifest(
        appVersion = "0.1.0", name = "Test", width = 100, height = 50, dpi = 72,
        layers = listOf(
            LayerEntry("a1", "Background", "layers/a1.png", visible = true, opacity = 1f, locked = false),
            LayerEntry("b2", "Sketch", "layers/b2.png", visible = false, opacity = 0.3f, locked = true),
        ),
    )

    private fun zip(vararg entries: Pair<String, ByteArray>): ByteArray {
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { z ->
            for ((name, bytes) in entries) {
                z.putNextEntry(ZipEntry(name))
                z.write(bytes)
                z.closeEntry()
            }
        }
        return bos.toByteArray()
    }

    @Test
    fun manifestRoundTrip() {
        val m = sample()
        assertEquals(m, ManifestCodec.decode(ManifestCodec.encode(m)))
    }

    @Test
    fun rejectsNewerFormatVersion() {
        val json = JSONObject(ManifestCodec.encode(sample())).put("formatVersion", 99).toString()
        assertThrows(UnsupportedVersionException::class.java) { ManifestCodec.decode(json) }
    }

    @Test
    fun rejectsMissingFormatVersion() {
        val json = JSONObject(ManifestCodec.encode(sample())).apply { remove("formatVersion") }.toString()
        assertThrows(ProjectFormatException::class.java) { ManifestCodec.decode(json) }
    }

    @Test
    fun rejectsPathTraversalInLayerFile() {
        val bad = sample().let { it.copy(layers = listOf(it.layers[0].copy(file = "../evil.png"))) }
        assertThrows(ProjectFormatException::class.java) { ManifestCodec.encode(bad) }
        val json = ManifestCodec.encode(sample()).replace("layers/a1.png", "../a1.png")
        assertThrows(ProjectFormatException::class.java) { ManifestCodec.decode(json) }
    }

    @Test
    fun rejectsDuplicateLayerIds() {
        val m = sample()
        val bad = m.copy(layers = listOf(m.layers[0], m.layers[1].copy(id = "a1", file = "layers/a1.png")))
        assertThrows(ProjectFormatException::class.java) { ManifestCodec.encode(bad) }
    }

    @Test
    fun rejectsOutOfRangeValues() {
        assertThrows(ProjectFormatException::class.java) { ManifestCodec.encode(sample().copy(width = 0)) }
        assertThrows(ProjectFormatException::class.java) { ManifestCodec.encode(sample().copy(height = 100_000)) }
        val m = sample()
        val badOpacity = m.copy(layers = listOf(m.layers[0].copy(opacity = 1.5f)))
        assertThrows(ProjectFormatException::class.java) { ManifestCodec.encode(badOpacity) }
    }

    @Test
    fun containerRoundTrip() {
        val m = sample()
        val bos = ByteArrayOutputStream()
        Nupx.write(bos, m) { e -> "png-${e.id}".toByteArray() }
        val data = Nupx.read(ByteArrayInputStream(bos.toByteArray()))
        assertEquals(m, data.manifest)
        assertEquals("png-a1", String(data.layerPng.getValue("layers/a1.png")))
        assertEquals("png-b2", String(data.layerPng.getValue("layers/b2.png")))
    }

    @Test
    fun readRejectsMissingLayerEntry() {
        val bytes = zip(Nupx.MANIFEST to ManifestCodec.encode(sample()).toByteArray(), "layers/a1.png" to byteArrayOf(1))
        assertThrows(ProjectFormatException::class.java) { Nupx.read(ByteArrayInputStream(bytes)) }
    }

    @Test
    fun readRejectsMissingManifest() {
        val bytes = zip("layers/a1.png" to byteArrayOf(1))
        assertThrows(ProjectFormatException::class.java) { Nupx.read(ByteArrayInputStream(bytes)) }
    }

    @Test
    fun readIgnoresUnknownEntries() {
        val bytes = zip(
            Nupx.MANIFEST to ManifestCodec.encode(sample()).toByteArray(),
            "layers/a1.png" to byteArrayOf(1),
            "layers/b2.png" to byteArrayOf(2),
            "future/extra.bin" to byteArrayOf(9),
            "../../escape.txt" to byteArrayOf(9),
        )
        val data = Nupx.read(ByteArrayInputStream(bytes))
        assertEquals(setOf("layers/a1.png", "layers/b2.png"), data.layerPng.keys)
    }

    @Test
    fun safeFileReplacesContentAndLeavesNoTempFile() {
        val f = File(tmp.root, "dir/p.nupx")
        SafeFile.writeAtomically(f) { it.write(1) }
        SafeFile.writeAtomically(f) { it.write(byteArrayOf(2, 3)) }
        assertArrayEquals(byteArrayOf(2, 3), f.readBytes())
        assertFalse(File(f.parentFile, "p.nupx.tmp").exists())
    }

    @Test
    fun safeFileKeepsOldContentWhenWriteFails() {
        val f = File(tmp.root, "p.nupx")
        SafeFile.writeAtomically(f) { it.write(byteArrayOf(7, 7)) }
        assertThrows(IOException::class.java) {
            SafeFile.writeAtomically(f) { throw IOException("disk full") }
        }
        assertArrayEquals(byteArrayOf(7, 7), f.readBytes())
        assertTrue(!File(tmp.root, "p.nupx.tmp").exists())
    }
}
