# Technical decisions

| # | Decision | Reason / consequence |
|---|----------|----------------------|
| 1 | Kotlin + Jetpack Compose, single Gradle module, packages per future engine | Fast to build; split into modules when engines appear (stage 2+). |
| 2 | `AppCompatActivity` as host | Needed for per-app language switching with persistence (`AppCompatDelegate.setApplicationLocales` + `autoStoreLocales`). |
| 3 | Project = zip `.npx` (`manifest.json` + `layers/*.png`) | Documented, inspectable, extensible to many layers; PNG is lossless. See `docs/PROJECT_FORMAT.md`. |
| 4 | Safe save: tmp file → verify → rename with `.bak`, recovered on start | A failed save never destroys the previous version. |
| 5 | `org.json` for the manifest | Built into Android, no plugin; JVM tests use the `org.json` artifact. |
| 6 | Max 8192 px side and ≤24 MP, further capped by heap (`core/Limits.kt`) | One full bitmap is drawn by Compose; above ~100 MB the canvas refuses to draw. Replaced by tiles in stage 2. |
| 7 | Photo Picker / system file dialogs, no storage permissions | Fewer permissions; works offline. |
| 8 | Theme and language stored separately (prefs / AppCompat) | Theme default is dark as required. |
| 9 | Only working UI is shown | No placeholders for layers/tools until they exist. |
| 10 | minSdk 24, targetSdk/compileSdk 35 | Wide device coverage, current platform. |
