# Nupixel

Mobile creative studio for Android. Current version: **0.1.0 (stage 1, not yet built or run)**.

## Build
1. Open the folder in Android Studio (Koala or newer, JDK 17) and let it sync, **or** run `gradle wrapper --gradle-version 8.9` once in the root and then `./gradlew assembleDebug`.
2. APK: `app/build/outputs/apk/debug/app-debug.apk`.
3. Unit tests: `./gradlew testDebugUnitTest`.

`gradle-wrapper.jar` and the `gradlew` scripts are not included (no network in the authoring environment); generate them with the command above.

## Layout
- `app/src/main/java/app/nupixel/core` – view transform math, device limits
- `.../data` – project format (`.npx`), project store, image import/export, prefs
- `.../ui` – theme (design tokens), shared components, screens
- `docs/` – design system, screen structure, project format, third-party list
- `branding/` – original icon and UI reference
- Status files: `PROJECT_STATUS.md`, `SESSION_REPORT.md`, `TECHNICAL_DECISIONS.md`, `TEST_STATUS.md`
