# Test status

| Check | Command | Last result |
|-------|---------|-------------|
| Unit tests (`ViewTransformTest`, `ManifestCodecTest`) | `./gradlew testDebugUnitTest` | **Not run** |
| Debug build | `./gradlew assembleDebug` | **Not run** |
| On-device / emulator run | — | **Not run** |
| Screenshots / visual check | — | **Not done** |
| Launcher icon on device | — | **Not checked** |

## Unverified stage 1 scenarios
Import image (incl. EXIF rotation, huge images) · blank canvas presets · save → close → reopen · overwrite safety · export PNG/JPEG at each size · unsaved-changes dialog · language switch and persistence · light/dark · .npx import/export · pinch/pan behaviour.

## Not covered by any test yet
`ProjectStore` (needs instrumented test), `ImageIO`, UI.

## Static review (2026-10-19, no compiler available in the authoring environment)
Scripted scan for missing imports in UI files: no real findings. This is not a compile check.
