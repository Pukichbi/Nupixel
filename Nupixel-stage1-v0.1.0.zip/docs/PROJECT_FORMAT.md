# Nupixel project format (.npx), version 1

ZIP archive:
- `manifest.json` (UTF-8 JSON)
- `layers/layer-1.png` (lossless PNG, ARGB)

```json
{
  "format": "nupixel-project",
  "formatVersion": 1,
  "appVersion": "0.1.0",
  "name": "Project",
  "canvas": { "width": 1920, "height": 1080, "colorSpace": "sRGB" },
  "createdAt": 1760000000000,
  "modifiedAt": 1760000000000,
  "layers": [
    { "id": "layer-1", "name": "Layer 1", "type": "raster", "file": "layers/layer-1.png", "visible": true, "opacity": 1.0 }
  ]
}
```

## Rules
- Files with `formatVersion` greater than the app supports are refused with a clear message.
- Older versions are upgraded step by step by `ManifestCodec.migrations` (none yet; v1 is the first).
- Layer `file` must start with `layers/` and must not contain `..`.
- Stage 1 reads and writes exactly one raster layer. Masks, blend modes, text, vector, animation arrive in later stages and will bump the version.
