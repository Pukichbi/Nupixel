# Third-party dependencies (all Apache-2.0, AndroidX / Kotlin)
Jetpack Compose (BOM 2024.09.03), Material 3, Material Icons Extended, AndroidX Core/AppCompat/Activity/Navigation/Lifecycle/ExifInterface, Kotlin stdlib. Tests: JUnit 4 (EPL-1.0), org.json (JSON licence). No network access at runtime; no analytics; no ads.
