# Screen structure (phone-first)

| # | Screen | Status in 0.1.0 |
|---|--------|-----------------|
| 1 | Home: logo, New project / Open image / Open project, bottom links Projects & Settings | implemented |
| 2 | Gallery / import: system Photo Picker | implemented (system UI) |
| 3 | Projects: list with thumbnails, size, time, export file, delete, empty state | implemented |
| 4 | Editor workspace: top bar (back, name, size, save, export), canvas with checkerboard, bottom view bar (Fit, 100%, zoom) | implemented, view only |
| 5 | Layers panel + layer properties: bottom sheet, opacity and blend mode | stage 4 |
| 6 | Tool rail (vertical, left, collapsible) + brush settings sheet (size/opacity/hardness) | stages 3 and 7 |
| 7 | Color correction and filters: bottom sheet with live preview | stage 6 |
| 8 | Export dialog: bottom sheet, PNG/JPEG, quality, size | implemented |
| 9 | Settings: theme, language, about | implemented (autosave interval etc. arrive with stage 5) |
| 10 | Recovery / error screen: dialog offering restore | stage 5; errors currently shown as snackbars |

Editor layout rules for later stages: canvas always fills the space; tools and panels slide over it; portrait uses a bottom rail, landscape a left rail; gestures act only on the canvas area.
