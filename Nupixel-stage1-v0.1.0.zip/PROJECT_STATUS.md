# Project status

**Stage:** 0.5 (design) + 1 (app foundation) — code written, **not built, not run**.
**Version:** 0.1.0 (versionCode 1)

## Done (written, unverified)
- Gradle project, manifest, adaptive launcher icon (from the user's original N), themed monochrome icon, in-app logo.
- Design tokens (dark default + light), shared components, 10-screen plan (`docs/SCREENS.md`).
- Screens: Home, New project (blank presets / from image), Projects (list, thumbnails, export `.npx`, delete), Editor (pan/zoom, fit/100%, double-tap, save, export sheet, unsaved-changes dialog), Settings (theme, language).
- RU/EN strings; language persisted through AppCompat per-app locales.
- Project format v1 (`.npx`), safe save (tmp → verify → swap, .bak recovery), manifest migration framework.
- PNG/JPEG export with size and quality; memory-aware import with EXIF orientation.
- Unit tests for view transform and manifest codec.

## Not done / limits
- Never compiled: first build may surface compile errors — fix those first.
- No emulator run, no screenshots, no icon check on a device.
- Editor has no editing tools yet (stage 3). Rotation gesture, grid, guides, crop/resize, tiles: stage 2.
- Open session is lost if Android kills the process (autosave/recovery: stage 5).
- Screens "Layers/properties", "Brushes", "Color correction" from the 0.5 list are planned only; not in the UI because they would not work yet.
- Gradle wrapper jar missing.

## Next action
Build `assembleDebug`, fix any compile errors, run `testDebugUnitTest`, install, then verify stage 1 criteria: import → view → save → reopen → export; check icon and both languages and themes.
