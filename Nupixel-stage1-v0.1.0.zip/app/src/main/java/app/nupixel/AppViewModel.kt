package app.nupixel

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import androidx.annotation.StringRes
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.nupixel.core.Limits
import app.nupixel.data.AppPrefs
import app.nupixel.data.ExportFormat
import app.nupixel.data.ImageIO
import app.nupixel.data.ImportException
import app.nupixel.data.LayerEntry
import app.nupixel.data.ProjectFormatException
import app.nupixel.data.ProjectInfo
import app.nupixel.data.ProjectManifest
import app.nupixel.data.ProjectStore
import app.nupixel.data.ProjectTooNewException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

class UiMessage(@StringRes val res: Int, val args: List<Any> = emptyList())

/** The document currently open in the editor. [dirty] = has changes not yet written to the .npx file. */
class Session(
    val id: String,
    val name: String,
    val bitmap: Bitmap,
    val createdAt: Long,
    val dirty: Boolean,
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ProjectStore(app)
    private val prefs = AppPrefs(app)
    private val versionName: String = try {
        app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "0"
    } catch (e: Exception) { "0" }

    var themeMode by mutableStateOf(prefs.theme); private set
    var session by mutableStateOf<Session?>(null); private set
    var projects by mutableStateOf<List<ProjectInfo>>(emptyList()); private set
    var busy by mutableStateOf(false); private set

    private val _messages = MutableSharedFlow<UiMessage>(extraBufferCapacity = 8)
    val messages = _messages.asSharedFlow()

    private fun say(@StringRes res: Int, vararg args: Any) { _messages.tryEmit(UiMessage(res, args.toList())) }

    fun setTheme(mode: String) { prefs.theme = mode; themeMode = mode }

    fun refreshProjects() {
        viewModelScope.launch { projects = withContext(Dispatchers.IO) { store.list() } }
    }

    /** Runs [block] on IO with the busy overlay shown; maps known failures to user messages. */
    private fun task(@StringRes failure: Int, block: suspend () -> Unit) {
        viewModelScope.launch {
            busy = true
            try {
                withContext(Dispatchers.IO) { block() }
            } catch (e: OutOfMemoryError) {
                say(R.string.err_memory)
            } catch (e: ProjectTooNewException) {
                say(R.string.err_project_new)
            } catch (e: ImportException) {
                say(R.string.err_import)
            } catch (e: ProjectFormatException) {
                say(R.string.err_open_project)
            } catch (e: IOException) {
                say(failure)
            } catch (e: SecurityException) {
                say(failure)
            } finally {
                busy = false
            }
        }
    }

    fun createBlank(name: String, width: Int, height: Int, background: Int, onDone: () -> Unit) {
        task(R.string.err_import) {
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(background)
            val s = Session(store.newId(), name, bmp, System.currentTimeMillis(), dirty = true)
            withContext(Dispatchers.Main) { session = s; onDone() }
        }
    }

    fun importImage(uri: Uri, fallbackName: String, onDone: () -> Unit) {
        task(R.string.err_import) {
            val ctx = getApplication<Application>()
            val d = ImageIO.decode(ctx, uri, Limits.maxPixels(), Limits.MAX_SIDE)
            val name = ImageIO.displayName(ctx, uri)?.takeIf { it.isNotBlank() } ?: fallbackName
            val s = Session(store.newId(), name, d.bitmap, System.currentTimeMillis(), dirty = true)
            withContext(Dispatchers.Main) {
                session = s
                if (d.downscaled) say(R.string.msg_downscaled, d.bitmap.width, d.bitmap.height)
                onDone()
            }
        }
    }

    fun openProject(id: String, onDone: () -> Unit) {
        task(R.string.err_open_project) {
            val p = store.load(id)
            val s = Session(p.id, p.manifest.name, p.bitmap, p.manifest.createdAt, dirty = false)
            withContext(Dispatchers.Main) { session = s; onDone() }
        }
    }

    fun importProjectFile(uri: Uri, onDone: () -> Unit) {
        task(R.string.err_open_project) {
            val ctx = getApplication<Application>()
            val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("no stream")
            val id = input.use { store.importFile(it) }
            val p = store.load(id)
            store.writeThumbnail(id, p.bitmap)
            val s = Session(p.id, p.manifest.name, p.bitmap, p.manifest.createdAt, dirty = false)
            withContext(Dispatchers.Main) { session = s; onDone() }
        }
    }

    fun saveSession(onResult: (Boolean) -> Unit = {}) {
        val s = session ?: return onResult(false)
        viewModelScope.launch {
            busy = true
            val ok = try {
                withContext(Dispatchers.IO) {
                    val now = System.currentTimeMillis()
                    store.save(
                        s.id,
                        ProjectManifest(
                            appVersion = versionName, name = s.name,
                            width = s.bitmap.width, height = s.bitmap.height,
                            createdAt = s.createdAt, modifiedAt = now,
                            layers = listOf(LayerEntry("layer-1", "Layer 1", "raster", "layers/layer-1.png")),
                        ),
                        s.bitmap,
                    )
                }
                true
            } catch (e: IOException) {
                false
            } catch (e: OutOfMemoryError) {
                false
            } finally {
                busy = false
            }
            if (ok) {
                session = Session(s.id, s.name, s.bitmap, s.createdAt, dirty = false)
                say(R.string.msg_saved)
            } else say(R.string.err_save)
            onResult(ok)
        }
    }

    fun closeSession() { session = null }

    fun exportImage(uri: Uri, format: ExportFormat, quality: Int, scale: Float) {
        val s = session ?: return
        task(R.string.err_export) {
            val ctx = getApplication<Application>()
            val out = ctx.contentResolver.openOutputStream(uri) ?: throw IOException("no stream")
            out.use { ImageIO.export(s.bitmap, format, quality, scale, it) }
            say(R.string.msg_exported)
        }
    }

    fun exportProjectFile(id: String, uri: Uri) {
        task(R.string.err_export) {
            val ctx = getApplication<Application>()
            val out = ctx.contentResolver.openOutputStream(uri) ?: throw IOException("no stream")
            out.use { store.copyTo(id, it) }
            say(R.string.msg_project_exported)
        }
    }

    fun deleteProject(id: String) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { store.delete(id) }
            if (ok) say(R.string.msg_deleted) else say(R.string.err_delete)
            projects = withContext(Dispatchers.IO) { store.list() }
        }
    }

    companion object {
        val TRANSPARENT = Color.TRANSPARENT
        val WHITE = Color.WHITE
        val BLACK = Color.BLACK
    }
}
