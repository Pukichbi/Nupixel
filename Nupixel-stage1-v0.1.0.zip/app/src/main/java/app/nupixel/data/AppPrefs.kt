package app.nupixel.data

import android.content.Context

class AppPrefs(context: Context) {
    private val sp = context.getSharedPreferences("nupixel_prefs", Context.MODE_PRIVATE)

    /** "dark" (default), "light" or "system". */
    var theme: String
        get() = sp.getString("theme", "dark") ?: "dark"
        set(v) = sp.edit().putString("theme", v).apply()
}
