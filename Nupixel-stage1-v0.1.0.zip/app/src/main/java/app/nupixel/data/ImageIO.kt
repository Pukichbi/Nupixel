package app.nupixel.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.provider.OpenableColumns
import androidx.exifinterface.media.ExifInterface
import java.io.IOException
import java.io.OutputStream
import kotlin.math.roundToInt

class ImportException : IOException("Cannot decode image")

enum class ExportFormat(val mime: String, val extension: String) {
    PNG("image/png", "png"),
    JPEG("image/jpeg", "jpg"),
}

object ImageIO {
    class Decoded(val bitmap: Bitmap, val originalWidth: Int, val originalHeight: Int) {
        val downscaled get() = bitmap.width != originalWidth || bitmap.height != originalHeight
    }

    @Throws(ImportException::class)
    fun decode(context: Context, uri: Uri, maxPixels: Long, maxSide: Int): Decoded {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        try {
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) } ?: throw ImportException()
        } catch (e: java.io.FileNotFoundException) {
            throw ImportException()
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw ImportException()

        val orientation = try {
            resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }

        var sample = 1
        while ((bounds.outWidth / sample).toLong() * (bounds.outHeight / sample) > maxPixels ||
            maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide
        ) sample *= 2

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inMutable = true
        }
        val decoded = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw ImportException()
        val oriented = applyOrientation(decoded, orientation)
        val swap = orientation in setOf(
            ExifInterface.ORIENTATION_ROTATE_90, ExifInterface.ORIENTATION_ROTATE_270,
            ExifInterface.ORIENTATION_TRANSPOSE, ExifInterface.ORIENTATION_TRANSVERSE,
        )
        val ow = if (swap) bounds.outHeight else bounds.outWidth
        val oh = if (swap) bounds.outWidth else bounds.outHeight
        return Decoded(oriented, ow, oh)
    }

    private fun applyOrientation(src: Bitmap, orientation: Int): Bitmap {
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return src
        }
        val out = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
        if (out !== src) src.recycle()
        return out
    }

    fun displayName(context: Context, uri: Uri): String? = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0)?.substringBeforeLast('.') else null
        }
    } catch (e: Exception) {
        null
    }

    /** Writes [bitmap] scaled by [scale]. JPEG has no alpha, so transparency is flattened onto white. */
    @Throws(IOException::class)
    fun export(bitmap: Bitmap, format: ExportFormat, quality: Int, scale: Float, out: OutputStream) {
        val w = (bitmap.width * scale).roundToInt().coerceAtLeast(1)
        val h = (bitmap.height * scale).roundToInt().coerceAtLeast(1)
        val scaled = if (w != bitmap.width || h != bitmap.height) Bitmap.createScaledBitmap(bitmap, w, h, true) else bitmap
        val toWrite = if (format == ExportFormat.JPEG) {
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also {
                Canvas(it).apply { drawColor(Color.WHITE); drawBitmap(scaled, 0f, 0f, null) }
            }
        } else scaled
        try {
            val cf = if (format == ExportFormat.PNG) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
            if (!toWrite.compress(cf, quality.coerceIn(1, 100), out)) throw IOException("Encode failed")
            out.flush()
        } finally {
            if (toWrite !== bitmap) toWrite.recycle()
            if (scaled !== bitmap && scaled !== toWrite) scaled.recycle()
        }
    }
}
