package app.nupixel.core

/** Device-dependent limits for document size. Stage 2 replaces full-bitmap drawing with tiles. */
object Limits {
    const val MAX_SIDE = 8192
    private const val HARD_MAX_PIXELS = 24_000_000L // 96 MB as ARGB_8888; stays below the canvas bitmap draw limit

    /** Pixels allowed for a single in-memory layer, from the app heap limit (~1/6 of heap for one bitmap). */
    fun maxPixels(): Long {
        val budgetBytes = Runtime.getRuntime().maxMemory() / 6
        return (budgetBytes / 4).coerceIn(2_000_000L, HARD_MAX_PIXELS)
    }

    fun maxMegapixels(): Int = (maxPixels() / 1_000_000L).toInt()
}
