package app.nupixel.core

import kotlin.math.min

/**
 * Maps document coordinates (image pixels) to screen coordinates (view pixels):
 * screen = doc * scale + offset. Pure Kotlin so it can be unit-tested on the JVM.
 */
data class ViewTransform(
    val scale: Float = 1f,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
) {
    fun docToScreenX(x: Float) = x * scale + offsetX
    fun docToScreenY(y: Float) = y * scale + offsetY
    fun screenToDocX(x: Float) = (x - offsetX) / scale
    fun screenToDocY(y: Float) = (y - offsetY) / scale

    fun panBy(dx: Float, dy: Float) = copy(offsetX = offsetX + dx, offsetY = offsetY + dy)

    /** Zoom by [factor] keeping the document point under ([focusX], [focusY]) fixed on screen. */
    fun zoomAround(focusX: Float, focusY: Float, factor: Float): ViewTransform {
        val newScale = (scale * factor).coerceIn(MIN_SCALE, MAX_SCALE)
        val applied = newScale / scale
        return ViewTransform(
            scale = newScale,
            offsetX = focusX - (focusX - offsetX) * applied,
            offsetY = focusY - (focusY - offsetY) * applied,
        )
    }

    companion object {
        const val MIN_SCALE = 0.02f
        const val MAX_SCALE = 64f

        /** Scale and center the document inside the view with [padding] px on every side. */
        fun fit(viewW: Float, viewH: Float, docW: Float, docH: Float, padding: Float = 0f): ViewTransform {
            val availW = (viewW - 2 * padding).coerceAtLeast(1f)
            val availH = (viewH - 2 * padding).coerceAtLeast(1f)
            val s = min(availW / docW, availH / docH).coerceIn(MIN_SCALE, MAX_SCALE)
            return ViewTransform(s, (viewW - docW * s) / 2f, (viewH - docH * s) / 2f)
        }
    }
}
