package app.nupixel.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.FitScreen
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import app.nupixel.AppViewModel
import app.nupixel.R
import app.nupixel.core.ViewTransform
import app.nupixel.data.ExportFormat
import app.nupixel.ui.components.NxButton
import app.nupixel.ui.components.NxSectionLabel
import app.nupixel.ui.components.NxSegmented
import app.nupixel.ui.theme.LocalNx
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private class PendingExport(val format: ExportFormat, val quality: Int, val scale: Float)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: AppViewModel, onLeave: () -> Unit) {
    val s = vm.session
    if (s == null) {
        // Session lost (e.g. process recreated): nothing to edit, go back.
        LaunchedEffect(Unit) { onLeave() }
        return
    }

    val density = LocalDensity.current
    val padPx = with(density) { 24.dp.toPx() }
    var viewSize by remember { mutableStateOf(IntSize.Zero) }
    var view by remember(s.id) { mutableStateOf(ViewTransform()) }
    var fitted by remember(s.id) { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    var showUnsaved by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<PendingExport?>(null) }

    val docW = s.bitmap.width.toFloat()
    val docH = s.bitmap.height.toFloat()
    fun fitView() = ViewTransform.fit(viewSize.width.toFloat(), viewSize.height.toFloat(), docW, docH, padPx)

    LaunchedEffect(viewSize, s.id) {
        if (viewSize != IntSize.Zero && !fitted) { view = fitView(); fitted = true }
    }

    val requestLeave: () -> Unit = {
        if (s.dirty) {
            showUnsaved = true
        } else {
            onLeave()
        }
    }
    BackHandler { requestLeave() }

    val pngLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(ExportFormat.PNG.mime)) { uri ->
        val p = pending
        if (uri != null && p != null) vm.exportImage(uri, p.format, p.quality, p.scale)
        pending = null
    }
    val jpgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(ExportFormat.JPEG.mime)) { uri ->
        val p = pending
        if (uri != null && p != null) vm.exportImage(uri, p.format, p.quality, p.scale)
        pending = null
    }

    val cs = MaterialTheme.colorScheme
    val nx = LocalNx.current
    val img = remember(s.bitmap) { s.bitmap.asImageBitmap() }

    Column(Modifier.fillMaxSize().background(cs.background)) {
        // Top bar
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().height(56.dp).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = requestLeave) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.cd_back)) }
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(s.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (s.dirty) {
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.size(8.dp).background(nx.warning, CircleShape))
                    }
                }
                Text("${s.bitmap.width} × ${s.bitmap.height} px", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            IconButton(onClick = { vm.saveSession() }) { Icon(Icons.Rounded.Save, stringResource(R.string.editor_save)) }
            IconButton(onClick = { showExport = true }) { Icon(Icons.Rounded.Share, stringResource(R.string.editor_export)) }
        }

        // Canvas
        Box(
            Modifier.weight(1f).fillMaxWidth().background(nx.canvasBackground).clipToBounds()
                .onSizeChanged { viewSize = it }
                .pointerInput(s.id) {
                    detectTransformGestures { centroid, pan, zoom, _ ->
                        view = view.panBy(pan.x, pan.y).zoomAround(centroid.x, centroid.y, zoom)
                    }
                }
                .pointerInput(s.id, viewSize) {
                    detectTapGestures(onDoubleTap = { p ->
                        view = if (abs(view.scale - 1f) < 0.01f) fitView() else view.zoomAround(p.x, p.y, 1f / view.scale)
                    })
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val v = view
                val left = v.offsetX
                val top = v.offsetY
                val w = docW * v.scale
                val h = docH * v.scale
                clipRect(left, top, left + w, top + h) {
                    drawChecker(left, top, w, h, nx.checkerLight, nx.checkerDark)
                }
                withTransform({
                    translate(left, top)
                    scale(v.scale, v.scale, pivot = Offset.Zero)
                }) {
                    drawImage(img, filterQuality = if (v.scale >= 2f) FilterQuality.None else FilterQuality.Medium)
                }
            }
        }

        // Bottom bar: view controls only (editing tools arrive in stage 3)
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ChipButton(stringResource(R.string.editor_fit), { view = fitView() }, leading = { Icon(Icons.Rounded.FitScreen, null, Modifier.size(18.dp)) })
            ChipButton(stringResource(R.string.editor_actual), { view = view.zoomAround(viewSize.width / 2f, viewSize.height / 2f, 1f / view.scale) })
            Spacer(Modifier.weight(1f))
            Text("${(view.scale * 100).roundToInt()}%", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
        }
    }

    if (showExport) {
        ModalBottomSheet(onDismissRequest = { showExport = false }, containerColor = cs.surfaceContainer) {
            ExportSheet(
                projectName = s.name, width = s.bitmap.width, height = s.bitmap.height,
                onExport = { format, quality, scale ->
                    showExport = false
                    pending = PendingExport(format, quality, scale)
                    val fileName = "${s.name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "image" }}.${format.extension}"
                    if (format == ExportFormat.PNG) pngLauncher.launch(fileName) else jpgLauncher.launch(fileName)
                },
            )
        }
    }

    if (showUnsaved) {
        AlertDialog(
            onDismissRequest = { showUnsaved = false },
            title = { Text(stringResource(R.string.unsaved_title)) },
            text = { Text(stringResource(R.string.unsaved_text, s.name)) },
            confirmButton = {
                TextButton(onClick = { showUnsaved = false; vm.saveSession { ok -> if (ok) onLeave() } }) {
                    Text(stringResource(R.string.action_save))
                }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { showUnsaved = false; onLeave() }) {
                        Text(stringResource(R.string.action_discard), color = cs.error)
                    }
                    TextButton(onClick = { showUnsaved = false }) { Text(stringResource(R.string.action_cancel)) }
                }
            },
        )
    }
}

@Composable
private fun ChipButton(label: String, onClick: () -> Unit, leading: (@Composable () -> Unit)? = null) {
    val cs = MaterialTheme.colorScheme
    Surface(onClick = onClick, shape = MaterialTheme.shapes.small, color = cs.surfaceContainerHigh, contentColor = cs.onSurface, modifier = Modifier.height(40.dp)) {
        Row(Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            if (leading != null) { leading(); Spacer(Modifier.width(6.dp)) }
            Text(label, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun ExportSheet(projectName: String, width: Int, height: Int, onExport: (ExportFormat, Int, Float) -> Unit) {
    var format by remember { mutableStateOf(ExportFormat.PNG) }
    var quality by remember { mutableStateOf(92f) }
    var scalePercent by remember { mutableStateOf(100) }
    val cs = MaterialTheme.colorScheme

    Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 16.dp).navigationBarsPadding()) {
        Text(stringResource(R.string.export_title), style = MaterialTheme.typography.titleLarge)

        NxSectionLabel(stringResource(R.string.export_format))
        NxSegmented(
            options = listOf("png" to "PNG", "jpeg" to "JPEG"),
            selected = if (format == ExportFormat.PNG) "png" else "jpeg",
            onSelect = { format = if (it == "png") ExportFormat.PNG else ExportFormat.JPEG },
        )
        Text(
            stringResource(if (format == ExportFormat.PNG) R.string.export_png_note else R.string.export_jpeg_note),
            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp),
        )

        if (format == ExportFormat.JPEG) {
            NxSectionLabel(stringResource(R.string.export_quality))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Slider(value = quality, onValueChange = { quality = it }, valueRange = 40f..100f, modifier = Modifier.weight(1f))
                Text("${quality.roundToInt()}%", style = MaterialTheme.typography.labelLarge, modifier = Modifier.width(48.dp))
            }
        }

        NxSectionLabel(stringResource(R.string.export_size))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(100, 75, 50, 25).forEach { pct ->
                val w = max(1, (width * pct / 100f).roundToInt())
                val h = max(1, (height * pct / 100f).roundToInt())
                val on = scalePercent == pct
                Surface(
                    onClick = { scalePercent = pct },
                    shape = MaterialTheme.shapes.small,
                    color = if (on) cs.primary.copy(alpha = 0.14f) else cs.surfaceContainerHigh,
                    border = androidx.compose.foundation.BorderStroke(if (on) 1.5.dp else 1.dp, if (on) cs.primary else cs.outlineVariant),
                    modifier = Modifier.fillMaxWidth().heightIn48(),
                ) {
                    Box(Modifier.padding(horizontal = 14.dp), contentAlignment = Alignment.CenterStart) {
                        Text(stringResource(R.string.export_size_option, pct, w, h), style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        NxButton(stringResource(R.string.export_button), onClick = { onExport(format, quality.roundToInt(), scalePercent / 100f) }, icon = Icons.Rounded.Share)
    }
}

private fun Modifier.heightIn48(): Modifier = this.then(Modifier.height(48.dp))

private fun DrawScope.drawChecker(left: Float, top: Float, w: Float, h: Float, light: androidx.compose.ui.graphics.Color, dark: androidx.compose.ui.graphics.Color) {
    drawRect(light, Offset(left, top), Size(w, h))
    val cell = 12.dp.toPx()
    val x0 = max(left, 0f)
    val y0 = max(top, 0f)
    val x1 = min(left + w, size.width)
    val y1 = min(top + h, size.height)
    if (x1 <= x0 || y1 <= y0) return
    val firstRow = floor((y0 - top) / cell).toInt()
    val firstCol = floor((x0 - left) / cell).toInt()
    var row = firstRow
    var y = top + row * cell
    while (y < y1) {
        var col = firstCol
        var x = left + col * cell
        while (x < x1) {
            if ((row + col) % 2 != 0) drawRect(dark, Offset(x, y), Size(cell, cell))
            col++
            x += cell
        }
        row++
        y += cell
    }
}
