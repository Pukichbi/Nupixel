package app.nupixel.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import app.nupixel.AppViewModel
import app.nupixel.ui.screens.EditorScreen
import app.nupixel.ui.screens.HomeScreen
import app.nupixel.ui.screens.NewProjectScreen
import app.nupixel.ui.screens.ProjectsScreen
import app.nupixel.ui.screens.SettingsScreen

private object Routes {
    const val HOME = "home"
    const val NEW = "new"
    const val PROJECTS = "projects"
    const val EDITOR = "editor"
    const val SETTINGS = "settings"
}

@Composable
fun NupixelRoot(vm: AppViewModel) {
    val nav = rememberNavController()
    val snack = remember { SnackbarHostState() }
    val ctx = LocalContext.current

    LaunchedEffect(Unit) {
        vm.messages.collect { m -> snack.showSnackbar(ctx.getString(m.res, *m.args.toTypedArray())) }
    }

    val openEditor: () -> Unit = {
        nav.navigate(Routes.EDITOR) { launchSingleTop = true }
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        NavHost(nav, startDestination = Routes.HOME) {
            composable(Routes.HOME) {
                HomeScreen(
                    vm = vm,
                    onNewProject = { nav.navigate(Routes.NEW) },
                    onProjects = { nav.navigate(Routes.PROJECTS) },
                    onSettings = { nav.navigate(Routes.SETTINGS) },
                    onOpenEditor = openEditor,
                )
            }
            composable(Routes.NEW) {
                NewProjectScreen(vm = vm, onBack = { nav.popBackStack() }, onOpenEditor = openEditor)
            }
            composable(Routes.PROJECTS) {
                ProjectsScreen(vm = vm, onBack = { nav.popBackStack() }, onNew = { nav.navigate(Routes.NEW) }, onOpenEditor = openEditor)
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(vm = vm, onBack = { nav.popBackStack() })
            }
            composable(Routes.EDITOR) {
                EditorScreen(vm = vm, onLeave = { vm.closeSession(); nav.popBackStack() })
            }
        }
        SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 8.dp))
        if (vm.busy) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)).clickable(enabled = true, onClick = {}),
                contentAlignment = Alignment.Center,
            ) { CircularProgressIndicator() }
        }
    }
}
