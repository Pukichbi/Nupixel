package app.nupixel

import app.nupixel.core.ViewTransform
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ViewTransformTest {
    private val eps = 0.001f

    @Test fun docToScreenAndBack() {
        val v = ViewTransform(scale = 2.5f, offsetX = 40f, offsetY = -10f)
        val sx = v.docToScreenX(100f)
        val sy = v.docToScreenY(60f)
        assertEquals(100f, v.screenToDocX(sx), eps)
        assertEquals(60f, v.screenToDocY(sy), eps)
    }

    @Test fun zoomKeepsFocusPointFixed() {
        val v = ViewTransform(1f, 30f, 20f)
        val focusX = 200f
        val focusY = 150f
        val docX = v.screenToDocX(focusX)
        val docY = v.screenToDocY(focusY)
        val z = v.zoomAround(focusX, focusY, 3f)
        assertEquals(3f, z.scale, eps)
        assertEquals(focusX, z.docToScreenX(docX), eps)
        assertEquals(focusY, z.docToScreenY(docY), eps)
    }

    @Test fun zoomIsClamped() {
        val big = ViewTransform().zoomAround(0f, 0f, 1000f)
        val small = ViewTransform().zoomAround(0f, 0f, 0.00001f)
        assertEquals(ViewTransform.MAX_SCALE, big.scale, eps)
        assertEquals(ViewTransform.MIN_SCALE, small.scale, eps)
    }

    @Test fun fitCentersAndContains() {
        val v = ViewTransform.fit(1000f, 2000f, 4000f, 1000f, padding = 50f)
        assertEquals(0.225f, v.scale, eps) // (1000 - 100) / 4000
        assertEquals(50f, v.docToScreenX(0f), eps)
        assertEquals(950f, v.docToScreenX(4000f), eps)
        assertEquals(1000f, v.docToScreenY(500f), eps) // vertically centered
        assertTrue(v.docToScreenY(0f) > 0f)
    }

    @Test fun panMovesOffsetOnly() {
        val v = ViewTransform(2f, 10f, 10f).panBy(5f, -5f)
        assertEquals(2f, v.scale, eps)
        assertEquals(15f, v.offsetX, eps)
        assertEquals(5f, v.offsetY, eps)
    }
}
