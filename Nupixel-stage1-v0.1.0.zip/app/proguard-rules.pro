# Stage 1: minification is disabled. Rules will be added when release shrinking is enabled.
